import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  SectionList,
  StatusBar,
  TouchableOpacity,
  TextInput,
} from 'react-native';

const DATA = [
  {
    title: 'Tasks',
    data: ['Chores', 'Study', 'Sports', 'Food', 'Cook'],
  },
];

const App = () => {
  const [newTask, setNewTask] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const handleAddTask = () => {
    if (newTask.trim() !== '') {
      DATA[0].data.push(newTask);
      setNewTask('');
    }
  };

  const handleClearTasks = () => {
    DATA[0].data = [];
    setNewTask(newTask);
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
  };

  const filteredData = DATA[0].data.filter(task =>
    task.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <SafeAreaView style={styles.outerContainer}>
      <View style={styles.container}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search tasks"
          value={searchQuery}
          onChangeText={handleSearch}
        />
        <SectionList
          sections={[
            {
              title: 'Tasks',
              data: filteredData,
            },
          ]}
          keyExtractor={(item, index) => item + index}
          renderItem={({ item }) => (
            <View style={styles.item}>
              <Text style={styles.title}>{item}</Text>
            </View>
          )}
          renderSectionHeader={({ section: { title } }) => (
            <Text style={styles.header}>{title}</Text>
          )}
        />
        <View style={styles.addTaskContainer}>
          <TextInput
            style={styles.addTaskInput}
            placeholder="Add New Task"
            value={newTask}
            onChangeText={(text) => setNewTask(text)}
          />
          <TouchableOpacity
            style={styles.addTaskButton}
            onPress={handleAddTask}
          >
            <Text style={{ color: 'white' }}>Add</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity
          style={styles.clearTasksButton}
          onPress={handleClearTasks}
        >
          <Text style={{ color: 'white' }}>Clear Tasks</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  outerContainer: {
    flex: 1,
    borderColor: 'black',
    borderWidth: 2,
  },
  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
    marginHorizontal: 16,
  },
  searchInput: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
  },
  item: {
    backgroundColor: 'lightgreen',
    padding: 10,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: 'green',
    borderRadius: 8,
  },
  header: {
    fontSize: 30,
    marginBottom: 10,
  },
  title: {
    fontSize: 24,
  },
  addTaskContainer: {
    flexDirection: 'row',
    marginTop: 10,
  },
  addTaskInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 5,
    marginRight: 10,
    padding: 5,
  },
  addTaskButton: {
    backgroundColor: 'green',
    borderRadius: 5,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  clearTasksButton: {
    backgroundColor: 'red',
    borderRadius: 5,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
});

export default App;